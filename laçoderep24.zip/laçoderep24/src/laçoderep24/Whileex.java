package laçoderep24;

public class Whileex {

	public static void main(String[] args) {
		int x = 1;
		
		while (x <= 10) {
			System.out.println(+x);
			x++;
		}
	}

}
