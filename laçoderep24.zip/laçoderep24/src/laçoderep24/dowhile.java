package laçoderep24;

import java.util.Scanner;

public class dowhile {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int v1, v2;
		
		do {
		System.out.println("Digite o primeiro valor");
		v1 = in.nextInt();
		System.out.println("Digite o segundo valor maior que o primeiro");
		v2 = in.nextInt();
		if (v1 <= v2) {
			System.out.println("Valor primeiro valor e maior que o segundo, digite novamente");
		}
		} while (v1 <= v2);
		
		
		if (v1 <= v2) {
			while (v1 <= v2) {
				if (v1 % 2 == 1) {
					System.out.println("esses são os impares  "+v1);
				} else {
					System.out.println("esses são os pares  " +v1);
				}
				v1++;
			}
		} else {
			System.out.println("Valor primeiro valor e maior que o segundo");
		}
		in.close();
	}

}
